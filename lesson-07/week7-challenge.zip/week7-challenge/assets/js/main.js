$(document).ready(function () {

  $("#start").click(function () {
    $("body").toggleClass("go");
    return false;
  });
  
});