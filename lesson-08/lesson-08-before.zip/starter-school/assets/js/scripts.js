$(document).ready(function(){

  $('.hamburger-icon').click(function(){
    $('nav').slideToggle(1000);
    return false;
  });

});